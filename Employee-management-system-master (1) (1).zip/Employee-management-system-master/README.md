Employee management system
===========================

Java web app for managing employees in a company. Technologies: Java, HTML, CSS, SQL, JSP.
